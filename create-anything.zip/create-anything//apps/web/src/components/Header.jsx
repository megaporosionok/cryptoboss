import { TrendingUp, Bell, ChevronDown, Menu, X } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white dark:bg-[#1E1E1E] border-b border-[#E8EAEE] dark:border-[#333333] sticky top-0 z-50">
      <div className="px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Left - Logo and Navigation */}
        <div className="flex items-center">
          {/* Brand logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-[#FF8200] to-[#FF9C14] dark:from-[#FF8F1F] dark:to-[#FFA335] rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <span className="font-poppins text-xl font-semibold text-[#111827] dark:text-[#E0E0E0]">
              КриптоБосс
            </span>
          </div>

          {/* Primary navigation - desktop */}
          <nav className="hidden lg:flex items-center ml-8 space-x-8">
            <a
              href="#"
              className="font-poppins text-base font-medium text-[#FF7A00] dark:text-[#FF8F1F] underline decoration-2 underline-offset-4 decoration-[#FF7A00] dark:decoration-[#FF8F1F] hover:text-[#E56B00] dark:hover:text-[#FF7A00] transition-colors duration-200"
            >
              Игра
            </a>
            <a
              href="#"
              className="font-poppins text-base text-[#6B7280] dark:text-[#A0A0A0] hover:text-[#111827] dark:hover:text-[#E0E0E0] transition-colors duration-200 hover:underline decoration-2 underline-offset-4"
            >
              Активы
            </a>
            <a
              href="#"
              className="font-poppins text-base text-[#6B7280] dark:text-[#A0A0A0] hover:text-[#111827] dark:hover:text-[#E0E0E0] transition-colors duration-200 hover:underline decoration-2 underline-offset-4"
            >
              Биржа
            </a>
            <a
              href="#"
              className="font-poppins text-base text-[#6B7280] dark:text-[#A0A0A0] hover:text-[#111827] dark:hover:text-[#E0E0E0] transition-colors duration-200 hover:underline decoration-2 underline-offset-4"
            >
              Статистика
            </a>
          </nav>

          {/* Mobile hamburger menu */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden ml-4 p-2 hover:bg-[#F8FAFC] dark:hover:bg-[#333333] active:bg-[#F1F5F9] dark:active:bg-[#404040] transition-colors duration-200 rounded-md"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6 text-[#111827] dark:text-[#E0E0E0]" />
            ) : (
              <Menu className="w-6 h-6 text-[#111827] dark:text-[#E0E0E0]" />
            )}
          </button>
        </div>

        {/* Right - Notification and Profile */}
        <div className="flex items-center space-x-3 sm:space-x-4">
          {/* Notification button */}
          <button
            className="w-10 h-10 rounded-full border border-[#E1E4EA] dark:border-[#404040] bg-white dark:bg-[#333333] flex items-center justify-center hover:border-[#FF7A00] dark:hover:border-[#FF8F1F] hover:bg-[#FFF7F0] dark:hover:bg-[#404040] focus:border-[#FF7A00] dark:focus:border-[#FF8F1F] focus:outline-none focus:ring-2 focus:ring-[#FF7A00] dark:focus:ring-[#FF8F1F] focus:ring-offset-2 active:bg-[#FFEBE0] dark:active:bg-[#555555] transition-all duration-200"
            aria-label="Уведомления"
          >
            <Bell className="w-5 h-5 text-[#111827] dark:text-[#E0E0E0]" />
          </button>

          {/* Profile dropdown trigger */}
          <button className="flex items-center space-x-2 hover:bg-[#F8FAFC] dark:hover:bg-[#333333] active:bg-[#F1F5F9] dark:active:bg-[#404040] transition-colors duration-200 px-2 py-1 rounded-md group">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FF8200] to-[#FF9C14] dark:from-[#FF8F1F] dark:to-[#FFA335] flex items-center justify-center text-white font-poppins font-semibold">
              И
            </div>
            <span className="hidden sm:block font-poppins text-base font-medium text-[#111827] dark:text-[#E0E0E0] group-hover:text-[#FF7A00] dark:group-hover:text-[#FF8F1F] transition-colors duration-200">
              Игрок
            </span>
            <ChevronDown className="w-4 h-4 text-[#111827] dark:text-[#E0E0E0] hidden sm:block group-hover:text-[#FF7A00] dark:group-hover:text-[#FF8F1F] transition-colors duration-200" />
          </button>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-white dark:bg-[#1E1E1E] border-t border-[#E8EAEE] dark:border-[#333333]">
          <nav className="px-4 py-4 space-y-4">
            <a
              href="#"
              onClick={() => setIsMobileMenuOpen(false)}
              className="block font-poppins text-lg font-medium text-[#FF7A00] dark:text-[#FF8F1F] hover:text-[#E56B00] dark:hover:text-[#FF7A00] transition-colors duration-200 py-2 border-b border-[#F1F5F9] dark:border-[#333333]"
            >
              Игра
            </a>
            <a
              href="#"
              onClick={() => setIsMobileMenuOpen(false)}
              className="block font-poppins text-lg text-[#6B7280] dark:text-[#A0A0A0] hover:text-[#111827] dark:hover:text-[#E0E0E0] transition-colors duration-200 py-2 border-b border-[#F1F5F9] dark:border-[#333333]"
            >
              Активы
            </a>
            <a
              href="#"
              onClick={() => setIsMobileMenuOpen(false)}
              className="block font-poppins text-lg text-[#6B7280] dark:text-[#A0A0A0] hover:text-[#111827] dark:hover:text-[#E0E0E0] transition-colors duration-200 py-2 border-b border-[#F1F5F9] dark:border-[#333333]"
            >
              Биржа
            </a>
            <a
              href="#"
              onClick={() => setIsMobileMenuOpen(false)}
              className="block font-poppins text-lg text-[#6B7280] dark:text-[#A0A0A0] hover:text-[#111827] dark:hover:text-[#E0E0E0] transition-colors duration-200 py-2"
            >
              Статистика
            </a>
          </nav>
        </div>
      )}

      {/* Poppins Font */}
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');
        .font-poppins {
          font-family: 'Poppins', sans-serif;
        }
      `}</style>
    </header>
  );
}
