"use client";

import { useState } from "react";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Heart,
  Calendar,
  ShoppingCart,
  Home,
  Car,
  Plane,
  Ship,
  Smile,
} from "lucide-react";

export default function GameDashboard() {
  const [turn, setTurn] = useState(8);
  const [money, setMoney] = useState(24361);
  const [happiness, setHappiness] = useState(6);
  const [exchangeMoney, setExchangeMoney] = useState(0);
  const [multiplier, setMultiplier] = useState(7.62);
  const [chance, setChance] = useState(28);
  const [dailyExpenses, setDailyExpenses] = useState(166);
  const [ownedAssets, setOwnedAssets] = useState([]);
  const [showDeal, setShowDeal] = useState(true);

  const assets = [
    {
      id: 1,
      name: "Car",
      nameRu: "Машина",
      price: 30000,
      maintenance: 50,
      happiness: 3,
      icon: Car,
    },
    {
      id: 2,
      name: "Apartment",
      nameRu: "Квартира",
      price: 200000,
      maintenance: 500,
      happiness: 3,
      icon: Home,
    },
    {
      id: 3,
      name: "Dacha",
      nameRu: "Дача",
      price: 500000,
      maintenance: 1000,
      happiness: 3,
      icon: Home,
    },
    {
      id: 4,
      name: "Penthouse",
      nameRu: "Пентхаус",
      price: 2000000,
      maintenance: 1000,
      happiness: 2,
      icon: Home,
    },
    {
      id: 5,
      name: "Helicopter",
      nameRu: "Вертолет",
      price: 5000000,
      maintenance: 3000,
      happiness: 2,
      icon: Plane,
    },
    {
      id: 6,
      name: "Jet",
      nameRu: "Самолет",
      price: 10000000,
      maintenance: 5000,
      happiness: 2,
      icon: Plane,
    },
    {
      id: 7,
      name: "Villa",
      nameRu: "Вилла",
      price: 25000000,
      maintenance: 10000,
      happiness: 1,
      icon: Home,
    },
    {
      id: 8,
      name: "Yacht",
      nameRu: "Яхта",
      price: 100000000,
      maintenance: 100000,
      happiness: 1,
      icon: Ship,
    },
  ];

  const buyAsset = (asset) => {
    if (money >= asset.price) {
      setMoney(money - asset.price);
      setHappiness(happiness + asset.happiness);
      setDailyExpenses(dailyExpenses + asset.maintenance);
      setOwnedAssets([...ownedAssets, asset.id]);
    }
  };

  const endTurn = () => {
    setTurn(turn + 1);
    setMoney(money - dailyExpenses);
    setShowDeal(Math.random() > 0.5); // Random chance to show deal
  };

  const acceptDeal = () => {
    setMoney(money + 26574);
    setHappiness(Math.max(1, happiness - 2));
    setShowDeal(false);
  };

  const declineDeal = () => {
    setMoney(money - 639);
    setShowDeal(false);
  };

  const trade = () => {
    if (exchangeMoney > 0) {
      const isWin = Math.random() < chance / 100;
      if (isWin) {
        const winAmount = exchangeMoney * multiplier;
        setMoney(money + winAmount);
      } else {
        setMoney(money - exchangeMoney);
      }
      setExchangeMoney(0);
    }
  };

  const formatMoney = (amount) => {
    return new Intl.NumberFormat("en-US").format(amount);
  };

  // Generate random candlestick chart data
  const generateChartBars = () => {
    const bars = [];
    for (let i = 0; i < 40; i++) {
      const isGreen = Math.random() > 0.5;
      const height = Math.random() * 60 + 20;
      bars.push(
        <div
          key={i}
          className={`w-1 ${isGreen ? "bg-green-400" : "bg-red-400"} opacity-70`}
          style={{ height: `${height}px` }}
        />,
      );
    }
    return bars;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A1628] via-[#1E3A8A] to-[#1E40AF] p-4 font-sans text-white">
      {/* Header */}
      <div className="text-center mb-6">
        <h1 className="text-4xl font-bold text-yellow-300 mb-4 tracking-wider">
          TURN {turn}
        </h1>
        <div className="w-full h-px bg-gradient-to-r from-transparent via-yellow-300 to-transparent mb-6"></div>

        {/* Balance and Happiness */}
        <div className="flex justify-between items-center max-w-4xl mx-auto">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-black" />
            </div>
            <span className="text-xl font-bold">
              BALANCE: ${formatMoney(money)}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold">HAPPINESS: {happiness}</span>
            <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
              <Smile className="w-5 h-5 text-black" />
            </div>
            <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
              <span className="text-black font-bold">₿</span>
            </div>
          </div>
        </div>
      </div>

      {/* Dark Crypto Deal */}
      {showDeal && (
        <div className="bg-gradient-to-r from-blue-900/50 to-blue-800/50 border border-blue-400/30 rounded-xl p-6 mb-6 backdrop-blur-sm">
          <h2 className="text-2xl font-bold text-center mb-4 text-white">
            DARK CRYPTO DEAL
          </h2>
          <p className="text-center text-gray-300 mb-2">
            Opportunity to Launder Crypto.
          </p>
          <p className="text-center mb-4">
            <span className="text-green-400">
              Accept: +$26574, -2 Happiness.
            </span>
            <br />
            <span className="text-red-400">Decline: -$639.</span>
          </p>
          <div className="flex gap-4 justify-center">
            <button
              onClick={acceptDeal}
              className="px-8 py-3 bg-green-500 hover:bg-green-600 rounded-full text-white font-bold text-lg border-2 border-green-400 shadow-lg shadow-green-500/25 transition-all duration-200"
            >
              ACCEPT
            </button>
            <button
              onClick={declineDeal}
              className="px-8 py-3 bg-red-500 hover:bg-red-600 rounded-full text-white font-bold text-lg border-2 border-red-400 shadow-lg shadow-red-500/25 transition-all duration-200"
            >
              DECLINE
            </button>
          </div>
        </div>
      )}

      {/* Trading Chart */}
      <div className="bg-gradient-to-r from-blue-900/50 to-blue-800/50 border border-blue-400/30 rounded-xl p-6 mb-6 backdrop-blur-sm">
        <div className="flex items-end justify-center gap-1 h-24 mb-4">
          {generateChartBars()}
        </div>
        <div className="text-center">
          <span className="text-xl font-bold">
            MULTIPLIER: {multiplier}x | CHANCE: {chance}%
          </span>
        </div>
      </div>

      {/* Investment Section */}
      <div className="bg-gradient-to-r from-blue-900/50 to-blue-800/50 border border-blue-400/30 rounded-xl p-6 mb-6 backdrop-blur-sm">
        <div className="flex items-center justify-between mb-4">
          <span className="text-lg font-bold">
            INVEST IN CRYPTO EXCHANGE: ${formatMoney(exchangeMoney)}
          </span>
          <button
            onClick={trade}
            disabled={exchangeMoney === 0}
            className="px-6 py-2 bg-blue-500 hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed rounded-full text-white font-bold border-2 border-blue-400 shadow-lg shadow-blue-500/25 transition-all duration-200"
          >
            INVEST
          </button>
        </div>
        <input
          type="range"
          min="0"
          max={money}
          value={exchangeMoney}
          onChange={(e) => setExchangeMoney(Number(e.target.value))}
          className="w-full h-2 bg-blue-800 rounded-lg appearance-none cursor-pointer slider"
        />
      </div>

      {/* Assets Grid */}
      <div className="bg-gradient-to-r from-blue-900/50 to-blue-800/50 border border-blue-400/30 rounded-xl p-6 mb-6 backdrop-blur-sm">
        <h2 className="text-2xl font-bold text-center mb-6">ASSETS</h2>
        <div className="grid grid-cols-4 gap-4">
          {assets.map((asset) => {
            const Icon = asset.icon;
            const isOwned = ownedAssets.includes(asset.id);
            const canAfford = money >= asset.price;

            return (
              <div
                key={asset.id}
                className="bg-gradient-to-b from-blue-800/50 to-blue-900/50 border border-blue-400/30 rounded-lg p-4 text-center backdrop-blur-sm"
              >
                <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center">
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-lg mb-2">{asset.name}</h3>
                <button
                  onClick={() => buyAsset(asset)}
                  disabled={!canAfford || isOwned}
                  className={`w-full py-2 rounded-full font-bold text-sm border-2 transition-all duration-200 ${
                    isOwned
                      ? "bg-gray-600 border-gray-500 text-gray-300 cursor-not-allowed"
                      : canAfford
                        ? "bg-blue-500 hover:bg-blue-600 border-blue-400 text-white shadow-lg shadow-blue-500/25"
                        : "bg-gray-700 border-gray-600 text-gray-400 cursor-not-allowed"
                  }`}
                >
                  {isOwned ? "Купить" : canAfford ? "Купить" : "Purchase"}
                </button>
                <p className="text-green-400 text-sm mt-2">
                  Happiness: +{asset.happiness}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Daily Expenses */}
      <div className="text-center mb-6">
        <span className="text-xl font-bold">
          DAILY LIVING EXPENSES: ${formatMoney(dailyExpenses)}/day
        </span>
      </div>

      {/* End Turn Button */}
      <div className="text-center">
        <button
          onClick={endTurn}
          className="px-12 py-4 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 rounded-full text-white font-bold text-xl border-2 border-blue-400 shadow-lg shadow-blue-500/25 transition-all duration-200"
        >
          END TURN
        </button>
      </div>

      {/* Custom Slider Styles */}
      <style jsx global>{`
        .slider::-webkit-slider-thumb {
          appearance: none;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: #3B82F6;
          border: 2px solid #60A5FA;
          cursor: pointer;
          box-shadow: 0 0 10px rgba(59, 130, 246, 0.5);
        }
        
        .slider::-moz-range-thumb {
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: #3B82F6;
          border: 2px solid #60A5FA;
          cursor: pointer;
          box-shadow: 0 0 10px rgba(59, 130, 246, 0.5);
        }
      `}</style>
    </div>
  );
}
